// register.js
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('register-form');
  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    const res = await fetch('http://localhost:8080/register', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();

    if (res.ok) {
      alert(result.message || 'Registration successful!');
      window.location.href = './login.html';
    } else {
      alert('Registration failed: ' + (result.error || JSON.stringify(result)));
    }
  });
});