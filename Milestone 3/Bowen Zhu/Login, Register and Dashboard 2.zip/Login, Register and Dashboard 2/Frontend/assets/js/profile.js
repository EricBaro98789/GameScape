// assets/js/profile.js
document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const response = await fetch('http://localhost:8080/profile', {
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (response.ok) {
          const { address, avatar_url } = await response.json();
          // Fill in the address field
          document.getElementById('address').value = address || '';

          if (avatar_url) {
            const preview = document.getElementById('avatar-preview');
            preview.src = avatar_url;
            preview.style.display = 'block';
          }
        } else {
          console.warn('Failed to fetch profile, status:', response.status);
        }
      } catch (error) {
        console.error('Error fetching /profile:', error);
      }
    }

    // Avatar image preview
    const avatarInput = document.getElementById('avatar');
    const previewImage = document.getElementById('avatar-preview');

    avatarInput.addEventListener('change', () => {
      const file = avatarInput.files[0];
      if (file) {
        previewImage.src = URL.createObjectURL(file);
        previewImage.style.display = 'block';
      } else {
        previewImage.style.display = 'none';
      }
    });

    // Submit profile update
    const form = document.getElementById('profile-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      const token = localStorage.getItem('token');

      try {
        const res = await fetch('http://localhost:8080/profile/update', {
          method: 'PUT',
          headers: {
            'Authorization': 'Bearer ' + token
          },
          body: formData
        });
        const result = await res.json();
        if (res.ok) {
          alert(result.message || 'Profile updated successfully!');
        } else {
          alert('Update failed: ' + (result.error || JSON.stringify(result)));
        }
      } catch (err) {
        console.error('Error submitting /profile/update:', err);
        alert('Network error, update failed');
      }
    });
  });