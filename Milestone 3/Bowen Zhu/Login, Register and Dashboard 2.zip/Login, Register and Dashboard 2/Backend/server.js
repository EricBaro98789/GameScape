// Import necessary libraries
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const bcrypt = require('bcryptjs'); // Using bcryptjs
const jwt = require('jsonwebtoken');
const { Sequelize, DataTypes } = require('sequelize');

const multer = require('multer');
const path   = require('path');

const upload = multer({
  dest: path.join(__dirname, 'uploads')
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './gamescape_database.sqlite',
  logging: console.log
});

// Define user model. modify avatar and address
const User = sequelize.define('User', {
  id:         { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  username:   { type: DataTypes.STRING,  allowNull: false },
  email:      { type: DataTypes.STRING,  allowNull: false, unique: true, validate: { isEmail: true } },
  password:   { type: DataTypes.STRING,  allowNull: false },
  address:    { type: DataTypes.STRING,  allowNull: true },   // new function
  avatar_url: { type: DataTypes.STRING,  allowNull: true }    // new function
}, {
  tableName: 'users'
});

const CollectedGame = sequelize.define('CollectedGame', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  rawgGameId: { type: DataTypes.INTEGER, allowNull: false },
  gameTitle: { type: DataTypes.STRING, allowNull: false },
  gameImage: { type: DataTypes.STRING, allowNull: true },
  rating: {
    type: DataTypes.FLOAT,
    allowNull: true
  }

}, { tableName: 'collected_games' });

User.hasMany(CollectedGame, {
  foreignKey: { name: 'userId', allowNull: false },
  onDelete: 'CASCADE'
});
CollectedGame.belongsTo(User, {
  foreignKey: { name: 'userId', allowNull: false }
});

// Express App Setup
const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 8080; // Ensure this matches frontend calls
const RAWG_API_KEY = '49019cbf03744419a483362b07d2f0a1';

// JWT Secret Key
const JWT_SECRET = 'YOUR_VERY_OWN_SUPER_STRONG_AND_RANDOM_SECRET_KEY_123!@#';

// insert Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Forbidden: Invalid or expired token' });
  }
}
// insert Middleware

app.get('/', (req, res) => {
  res.send('Hello World! Your GameScape backend server is running.');
});

// search games from RAWG
app.get('/api/games/search', async (req, res) => {
  const { query: searchQuery } = req.query;
  if (!searchQuery) {
    return res.status(400).json({ message: 'Search query is required' });
  }
  if (!RAWG_API_KEY) {
    console.error('RAWG API Key is missing in server config.');
    return res.status(500).json({ message: 'Server configuration error' });
  }
  const rawgUrl = `https://api.rawg.io/api/games`;
  try {
    console.log(`Searching RAWG for: ${searchQuery}`);
    const response = await axios.get(rawgUrl, {
      params: { key: RAWG_API_KEY, search: searchQuery, page_size: 10 }
    });
    console.log(`Successfully fetched search data from RAWG.`);
    res.json(response.data);
  } catch (error) {
    console.error('Error fetching search data from RAWG API:', error.message);
    if (error.response) {
      console.error('RAWG Response Status:', error.response.status, 'Data:', error.response.data);
    }
    res.status(500).json({ message: 'Error fetching data from external API' });
  }
});

// Get game details from RAWG
app.get('/api/games/:id', async (req, res) => {
  const { id: gameId } = req.params;
  if (!RAWG_API_KEY) {
    console.error('RAWG API Key is missing in server config for game details.');
    return res.status(500).json({ message: 'Server configuration error' });
  }
  if (!gameId) {
    return res.status(400).json({ message: 'Game ID is required' });
  }
  const rawgDetailUrl = `https://api.rawg.io/api/games/${gameId}`;
  try {
    console.log(`Fetching details for game ID: ${gameId} from RAWG...`);
    const response = await axios.get(rawgDetailUrl, {
      params: { key: RAWG_API_KEY }
    });
    console.log(`Successfully fetched details for game ID: ${gameId}`);
    res.json(response.data);
  } catch (error) {
    console.error(`Error fetching details for game ID ${gameId} from RAWG API:`, error.message);
    if (error.response) {
      console.error('RAWG Response Status:', error.response.status, 'Data:', error.response.data);
    }
    res.status(500).json({ message: `Error fetching game details for ID ${gameId}` });
  }
});

// User Registration  insert avatar and address
app.post('/register', async (req, res) => {
  try {
    const { username, email, password, address, avatar } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Username, email, and password are required' });
    }

    const existingUser = await User.findOne({ where: { email: email } });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const newUser = await User.create({
      username,
      email,
      password: hashedPassword,
      address: address || null,  // new function: address
      avatar_url: avatar || null // new function: avatar
    });

    console.log('User registered and saved to database:', newUser.toJSON());
    res.status(201).json({
      message: 'Registration successful!',
      user: { id: newUser.id, username: newUser.username, email: newUser.email }
    });
  } catch (error) {
    console.error("Error during database registration:", error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ error: 'Email already registered (database constraint).' });
    }
    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(e => e.message);
      return res.status(400).json({ error: 'Validation error(s)', details: messages });
    }
    res.status(500).json({ error: 'Server error during registration' });
  }
});
//insert avatar and address

// User Login
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    const userInDb = await User.findOne({ where: { email: email } });
    if (!userInDb) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const isMatch = await bcrypt.compare(password, userInDb.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const tokenPayload = { id: userInDb.id, email: userInDb.email, username: userInDb.username };
    const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '1h' });
    console.log(`User logged in successfully: ${userInDb.email} (ID: ${userInDb.id})`);
    res.json({
      message: 'Login successful!',
      token: token,
      user: { id: userInDb.id, username: userInDb.username, email: userInDb.email }
    });
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// Get current user's profile
app.get(
  '/profile',
  authenticateToken,
  async (req, res) => {
    const user = await User.findByPk(req.user.id, {
      attributes: ['username','email','address','avatar_url']
    });
    res.json(user);
  }
);

 // Update Profile: allow user to update avatar, address, password.
app.put(
  +    '/profile/update',
  +    authenticateToken,
  +    upload.single('avatar'),
  +    async (req, res) => {
  +      try {
  +        const userId = req.user.id;
  +        const updates = {};
  +        if (req.body.address) {
  +          updates.address = req.body.address;
  +        }
  +        if (req.body.password) {
  +          updates.password = await bcrypt.hash(req.body.password, 10);
  +        }
  +        if (req.file) {
  +          updates.avatar_url = '/uploads/' + req.file.filename;
  +        }
  +        await User.update(updates, { where: { id: userId } });
  +        const updatedUser = await User.findByPk(userId, {
  +          attributes: { exclude: ['password'] }
  +        });
  +        res.json({ message: 'Profile updated', user: updatedUser });
  +      } catch (error) {
  +        console.error('Error updating profile:', error);
  +        res.status(500).json({ error: 'Server error during profile update' });
  +      }
  +    }
  +  );
 // Update Profile

// Add game to user's collection
app.post('/collection', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or malformed token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decodedToken = jwt.verify(token, JWT_SECRET);
    const userIdFromToken = decodedToken.id;
    if (!userIdFromToken) {
      return res.status(403).json({ error: 'Forbidden: Token is invalid (missing user ID)' });
    }

    const { gameId, gameTitle, gameImage, rating } = req.body; // Expect rating from frontend
    if (typeof gameId === 'undefined' || !gameTitle) {
      return res.status(400).json({ error: 'Bad Request: gameId and gameTitle are required' });
    }

    const existingEntry = await CollectedGame.findOne({
      where: { userId: userIdFromToken, rawgGameId: gameId }
    });
    if (existingEntry) {
      const currentCollection = await CollectedGame.findAll({ where: { userId: userIdFromToken } });
      return res.status(200).json({ message: 'Game is already in your collection', collection: currentCollection });
    }

    const gameToSave = {
      userId: userIdFromToken,
      rawgGameId: parseInt(gameId),
      gameTitle: gameTitle,
      gameImage: gameImage,
      rating: rating
    };
    console.log('POST /collection: Attempting to create entry in DB with:', gameToSave);
    const newCollectedGame = await CollectedGame.create(gameToSave);
    console.log(`POST /collection: Game rawgGameId ${newCollectedGame.rawgGameId} added to userId ${userIdFromToken}'s collection.`);
    const updatedCollection = await CollectedGame.findAll({ where: { userId: userIdFromToken }, order: [['createdAt', 'DESC']] });
    res.status(201).json({ message: 'Game added to your collection!', collection: updatedCollection });
  } catch (error) {
    console.error('POST /collection: Error ->', error.name, ':', error.message);
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return res.status(403).json({ error: 'Forbidden: Invalid or expired token.' });
    }
    console.error('POST /collection: Full error object:', error);
    res.status(500).json({ error: 'Server error while adding game to collection' });
  }
});

app.get('/collection', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or malformed token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decodedToken = jwt.verify(token, JWT_SECRET);
    const userIdFromToken = decodedToken.id;
    if (!userIdFromToken) {
      return res.status(403).json({ error: 'Forbidden: Token is invalid (missing user ID)' });
    }
    console.log(`GET /collection: Fetching collection for userId ${userIdFromToken}...`);
    const userCollection = await CollectedGame.findAll({
      where: { userId: userIdFromToken },
      order: [['createdAt', 'DESC']]
    });
    console.log(`GET /collection: Found ${userCollection.length} items for userId ${userIdFromToken}.`);
    res.status(200).json(userCollection);
  } catch (error) {
    console.error('GET /collection: Error ->', error.name, ':', error.message);
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return res.status(403).json({ error: 'Forbidden: Invalid or expired token.' });
    }
    console.error('GET /collection: Full error object:', error);
    res.status(500).json({ error: 'Server error while fetching collection' });
  }
});

// remove game from user's collection
app.delete('/collection/:rawgGameId', async (req, res) => {
    const authHeader = req.headers.authorization;
    const rawgGameIdToRemove = parseInt(req.params.rawgGameId);

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized: Missing or malformed token' });
    }
    const token = authHeader.split(' ')[1];

    if (isNaN(rawgGameIdToRemove)) {
        return res.status(400).json({ error: 'Bad Request: Valid rawgGameId parameter is required' });
    }

    try {
        const decodedToken = jwt.verify(token, JWT_SECRET);
        const userIdFromToken = decodedToken.id;
        if (!userIdFromToken) {
            return res.status(403).json({ error: 'Forbidden: Token is invalid (missing user ID)' });
        }

        console.log(`Attempting to remove rawgGameId: ${rawgGameIdToRemove} for userId: ${userIdFromToken}`);
        const result = await CollectedGame.destroy({
            where: { userId: userIdFromToken, rawgGameId: rawgGameIdToRemove }
        });

        if (result > 0) {
            console.log(`Game rawgGameId ${rawgGameIdToRemove} removed from collection for userId ${userIdFromToken}.`);
            const updatedCollection = await CollectedGame.findAll({ where: { userId: userIdFromToken }, order: [['createdAt', 'DESC']] });
            res.status(200).json({ message: 'Game removed from collection', collection: updatedCollection });
        } else {
            console.log(`Game rawgGameId ${rawgGameIdToRemove} not found in collection for userId ${userIdFromToken}.`);
            const currentCollection = await CollectedGame.findAll({ where: { userId: userIdFromToken }, order: [['createdAt', 'DESC']] });
            res.status(404).json({ error: 'Game not found in collection', collection: currentCollection });
        }
    } catch (error) {
        console.error('Error in DELETE /collection/:rawgGameId:', error.message);
        if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
            return res.status(403).json({ error: 'Forbidden: Invalid or expired token' });
        }
        res.status(500).json({ error: 'Server error while removing game from collection' });
    }
});

async function initializeDatabaseAndStartServer() {
  try {
    await sequelize.authenticate();
    console.log('Connection to the database has been established successfully.');

    await sequelize.sync({ alter: true }); //to insert avatar and address, modify false to ture.
    console.log('All models were synchronized successfully. Tables are ready.');
    app.listen(port, () => {
      console.log(`Server listening at http://localhost:${port}`);
    });
  } catch (error) {
    console.error('Unable to connect to the database or sync models:', error);
    process.exit(1);
  }
}

initializeDatabaseAndStartServer();
